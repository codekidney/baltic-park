<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'rkserv_baltic-park' );

/** MySQL database username */
define( 'DB_USER', 'rkserv_baltic-park' );

/** MySQL database password */
define( 'DB_PASSWORD', '53ADeEI4' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'jYdp&t$NCayA+^NK+jmQ6JaOLK)z}R|d!2k<w;=5j<RnRcfEd[MnbUmt;Kc4URdC' );
define( 'SECURE_AUTH_KEY',  '{z#qPmeTJ=K@W%UYt-$aT;DoS%UwpH11B$6,;~w#drny8S>=tCT/X7/W3]A)V!#>' );
define( 'LOGGED_IN_KEY',    'LY&2Bs/dG; H.hhSed1]?ArU[E;5`YWkZVjR0.v^o Ns|u.:yZ[E2/r$yA8JNCWI' );
define( 'NONCE_KEY',        'F12TQ!4&9pi?0_6h[rK:[kCXTfO=pk<rIhHTM,#(|VpeXH{HR s4Hk^Yn04:;s95' );
define( 'AUTH_SALT',        'wRrK99T;(O8DsuyU o%>UevH2W[k0zD<*z~V^>4^._0.#:U=iV[=>o@~-.ETt/1U' );
define( 'SECURE_AUTH_SALT', ':,/*Ky$s:^nG,uWJx|BkCU6a1X*7*lwbfgH`u*O&11lYh}:woimjAPGawK48:%7^' );
define( 'LOGGED_IN_SALT',   'MZP@&NjlH3Ef`7l%iN(VQ!iCb0uWK)*s=oh@;W>K7b51;}!8K*1xoU+7FD9bVi((' );
define( 'NONCE_SALT',       ' S=CVpEPz8T](J#NQW+~Pv7pSBHZTSB3 yu#(r;tvA{}OY>?DlZgwZA]7|=6*+)k' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
